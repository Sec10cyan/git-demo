/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include <stdio.h>
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "oled.h"
#include "ti_msp_dl_config.h"

volatile int state = 0;
volatile int count = 0;
int main(void)
{
    // ??????
    board_init();
    SYSCFG_DL_init();
    NVIC_EnableIRQ(KEY_INT_IRQN);
    uint8_t ret = 1;
          
    while(1) 
    {		
			
        if (state == 1){
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C0_IDX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, 556 , GPIO_PWM_0_C1_IDX); //right
            DL_TimerG_setCaptureCompareValue(PWM_1_INST, 598 , GPIO_PWM_1_C0_IDX);
            DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C1_IDX); //left
        }
        if (state == 0){
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C0_IDX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C1_IDX);
            DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C0_IDX);
            DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C1_IDX);
        }
        if (state == 2){
            // ??8/9??
            if(DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_9_PIN) == 0 || DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_8_PIN) == 0)
            {
                DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C0_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_0_INST, 755 , GPIO_PWM_0_C1_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_1_INST, 430 , GPIO_PWM_1_C0_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C1_IDX);
            }
            // ??2/3??
            if(DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_3_PIN) == 0 || DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_2_PIN) == 0)
            {
                DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C0_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_0_INST, 430 , GPIO_PWM_0_C1_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_1_INST, 755 , GPIO_PWM_1_C0_IDX);
                DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C1_IDX);
            }
            // ====================== ?????? ======================
            if((DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_9_PIN) > 0 && 
                DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_8_PIN) > 0 && 
                DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_3_PIN) > 0 && 
                DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_2_PIN) > 0))  // ???? )
            {
                delay_ms(80);
                if(DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_9_PIN) > 0 && 
                   DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_8_PIN) > 0 && 
                   DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_3_PIN) > 0 && 
                   DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_2_PIN) > 0)
                {
                    DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C0_IDX);
                    DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0 , GPIO_PWM_0_C1_IDX);
                    DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C0_IDX);
                    DL_TimerG_setCaptureCompareValue(PWM_1_INST, 0 , GPIO_PWM_1_C1_IDX);
                    delay_ms(1000);
                    count ++;
                    if(count != 2){
                        state = 1;
                    }
                    else{
                        state = 0;
                    }
                }
            }
        }
    }
}
void GROUP1_IRQHandler(void)//Group1???????
{
    //??Group1??????????????
    switch( DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1) )
    {
        //?????KEY?GPIOA????,???INT_IIDX,??PIN_18_IIDX
        case KEY_INT_IIDX:
            //???????????
            if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_18_PIN) > 0 )
            {
							  state = !state;
                //??LED??????
                DL_GPIO_togglePins(LED1_PORT, LED1_PIN_14_PIN);
            }
        break;
				case GPIO_INT_IIDX:
					  if((DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_9_PIN) == 0 || DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_8_PIN) == 0 || DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_3_PIN) == 0 || DL_GPIO_readPins(GPIO_PORT, GPIO_PIN_2_PIN) == 0) && state == 1)
            {
							 state = 2;
            }
				break;
     }
}











